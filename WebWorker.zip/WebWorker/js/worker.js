//worker script
//code executes immediatley upon script load

//add event handler to onmessage
//event raised when page send message to worker
//self represents the worker
self.onmessage = function(e){
//retrieve data.
//in this example it's a string
  var message = e.data;

//"process" the message 
  message += '- Processed!';

//send the message back to page
  self.postMessage(message);
}