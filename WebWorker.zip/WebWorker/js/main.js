//wait for the document to be loaded
$(function() {
//creat the worker
  var worker = new Worker('js/worker.js');

//creat event handeler for onmessage
//event raised when worker sends message to the page
  worker.onmessage = function(e) {

//retrieve data. in this case a string    
    var message = e.data;
  
//add new list item    
    $('#messageList').append('<li>' + message + '</li>');
  };
  
  
//creat event handler for click on btn  
  $('#send').click(function(){

//retrieve message from textbox
    var message = $('#message').val();

//send message to worker    
    worker.postMessage(message);
  });
  
});

